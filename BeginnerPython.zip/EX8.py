#!/usr/bin/env python
# coding: utf-8

# In[1]:


print("*              *")
print("*            *")
print("*          *")
print("*        *")
print("*     *")
print("*  *")
print("**")
print("*  *")
print("*     *")
print("*       *")
print("*         *")
print("*           *")
print("*              *")


# In[ ]:




